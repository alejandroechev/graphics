namespace SceneLib
{
  public interface IMeshLoader
  {
    void Load(MeshBase mesh);
  }
}