﻿using System;
using SceneLib;

namespace GPURenderer
{
  public class Triangle : TriangleBase
  {

    public override bool Intersect(Ray ray)
    {
      throw new NotImplementedException();
    }

    public override Vector GetNormal(Ray ray)
    {
      throw new NotImplementedException();
    }

    public override Material GetMaterial(Ray ray)
    {
      throw new NotImplementedException();
    }

    
  }
}