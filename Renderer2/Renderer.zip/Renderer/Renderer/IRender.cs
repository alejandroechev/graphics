namespace Renderer
{
  public interface IRender
  {
    string Name { get; }
    void Render();
  }
}