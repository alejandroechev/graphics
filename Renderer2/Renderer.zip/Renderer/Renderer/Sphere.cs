﻿using SceneLib;

namespace Renderer
{
  public class Sphere : SphereBase
  {
    public Sphere(MeshBase sphereMesh)
      : base(sphereMesh)
    {
    }

    public override bool Intersect(Ray ray)
    {
      throw new System.NotImplementedException();
    }

    public override Vector GetNormal(Vector point)
    {
      throw new System.NotImplementedException();
    }

    public override Material GetMaterial(Vector point)
    {
      throw new System.NotImplementedException();
    }
  }
}