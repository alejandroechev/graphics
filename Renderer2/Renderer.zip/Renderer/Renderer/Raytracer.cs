using SceneLib;

namespace Renderer
{
  public class Raytracer : IRender
  {
    private readonly Scene _scene;
    private readonly IDisplay _display;

    public string Name
    {
      get { return "Raytracer"; }
    }

    public Raytracer(Scene scene, IDisplay display)
    {
      _scene = scene;
      _display = display;
    }

    public void Render()
    {
      for (int i = 0; i < _scene.Width; i++)
      {
        for (int j = 0; j < _scene.Height; j++)
        {
          _display.SetPixel(i, j, 0, 0, 1);
        }
      }
      _display.UpdateDisplay();
    }
  }
}