﻿using SceneLib;

namespace Renderer
{
  public class Mesh : MeshBase
  {
    public Mesh(string name, string filename, IMeshLoader meshLoader, IRenderObjectFactory renderObjectFactory)
      : base(name, filename, meshLoader, renderObjectFactory)
    {
    }

    public override bool Intersect(Ray ray)
    {
      throw new System.NotImplementedException();
    }

    public override Vector GetNormal(Vector point)
    {
      throw new System.NotImplementedException();
    }

    public override Material GetMaterial(Vector point)
    {
      throw new System.NotImplementedException();
    }
  }
}